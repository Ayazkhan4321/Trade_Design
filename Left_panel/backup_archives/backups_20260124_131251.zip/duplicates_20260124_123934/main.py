"""
Main Application - Integrated Left Panel with MarketWatch and Accounts
Handles tab switching between Market View and Accounts modules
"""
import sys
import os
import importlib.util
from PySide6.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QTabWidget
from PySide6.QtCore import Qt, QEvent
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QTreeWidget, QTreeWidgetItemIterator

# Get absolute paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MARKETWATCH_DIR = os.path.join(BASE_DIR, 'MarketWatch_jetfyx')
ACCOUNTS_DIR = os.path.join(BASE_DIR, 'accounts')
# Ensure project root is on sys.path so packages import normally
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)
# Import MarketWatch components (packages resolve from project root)
from MarketWatch_jetfyx.ui.market_widget import MarketWidget
from MarketWatch_jetfyx.services.settings_service import SettingsService
from MarketWatch_jetfyx.services.order_service import OrderService
from MarketWatch_jetfyx.services.price_service import PriceService

# Import the complete Accounts MainWindow class
from accounts.main import MainWindow as AccountsWindow


class AccountsWidget(QWidget):
    """Accounts tab widget - wraps the complete accounts module"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent_window = parent
        
        # Create instance of the accounts window (won't show as separate window)
        # Pass auto_login=False to prevent automatic login dialog
        self.accounts_window = AccountsWindow(auto_login=False)
        # Don't show it as a window, we'll extract its content
        
        # Setup UI by extracting the accounts tab
        self._setup_ui()
    
    def _setup_ui(self):
        """Extract the accounts tree from AccountsWindow"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Get the accounts tab content (index 1)
        accounts_tab = self.accounts_window.tabs.widget(1)
        
        # Get the tree from that tab
        self.accounts_tree = self.accounts_window.accounts_tree
        
        # Remove tree from original layout and add to our layout
        accounts_tab.layout().removeWidget(self.accounts_tree)
        layout.addWidget(self.accounts_tree)
        
        # Forward status updates to parent if it has a status bar
        if hasattr(self.parent_window, 'statusBar') and hasattr(self.accounts_window, 'statusBar'):
            # Redirect status messages to parent
            original_show_message = self.accounts_window.statusBar().showMessage
            def forward_status(message, timeout=0):
                self.parent_window.statusBar().showMessage(message, timeout)
            self.accounts_window.statusBar().showMessage = forward_status
    
    def show_login_dialog(self):
        """Show login dialog from accounts module"""
        # Show the accounts module login dialog; after it closes, inspect
        # the shared AppStore for the selected account id so the MarketWidget
        # can be initialized with live data.
        self.accounts_window.show_login()

        # Inspect the AccountsWindow instance for the API response first
        account_id = None
        try:
            api_resp = getattr(self.accounts_window, 'api_response', None)
            if api_resp and isinstance(api_resp, dict):
                # api_response has user and accounts keys
                accounts_raw = api_resp.get('accounts') or api_resp.get('accounts', [])
                if accounts_raw and isinstance(accounts_raw, list) and len(accounts_raw) > 0:
                    first = accounts_raw[0]
                    account_id = first.get('accountNumber') or first.get('accountId') or first.get('number')
        except Exception:
            account_id = None

        # Fallback: try the central store (may be different module instance in some setups)
        if not account_id:
            try:
                from accounts.store import AppStore
                store = AppStore.instance()
                live_own = store.state.get("accounts", {}).get("live", {}).get("own", [])
                if live_own and len(live_own) > 0:
                    first = live_own[0]
                    account_id = first.get("id") or first.get("accountId") or first.get("number")
            except Exception:
                pass

        return account_id


class LeftPanelApp(QMainWindow):
    """Main application window with integrated tabs"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Trade Platform - Left Panel")
        self.setGeometry(100, 100, 420, 600)
        
        # Initialize services for MarketWatch
        self.settings_service = SettingsService()
        self.order_service = OrderService()
        self.price_service = PriceService()
        
        # Apply global styles
        self._apply_global_styles()
        
        # Setup UI
        self._setup_ui()
        
        # Show login dialog on startup
        self.show_login()
    
    def _apply_global_styles(self):
        """Apply global application styles"""
        self.setStyleSheet("""
            QMainWindow {
                background-color: #ffffff;
            }
            QTabWidget::pane {
                border: none;
                background-color: #ffffff;
                border-top: 2px solid #e0e0e0;
            }
            QTabBar::tab {
                background-color: #f5f5f5;
                color: #666666;
                padding: 12px 24px;
                border: none;
                border-bottom: 3px solid transparent;
                font-size: 14px;
                font-weight: 500;
            }
            QTabBar::tab:selected {
                color: #2563eb;
                border-bottom: 3px solid #2563eb;
                background-color: #ffffff;
            }
            QTabBar::tab:hover:!selected {
                color: #1e293b;
                background-color: #fafafa;
            }
            QTableView::item:hover {
                background: transparent;
            }
            QTableView::item:selected {
                background: #bbdefb;
            }
            QTableView::item:selected:!active {
                background: #bbdefb;
            }
        """)
    
    def _setup_ui(self):
        """Setup the main window UI"""
        # Create central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        layout = QVBoxLayout(central_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Create tab widget
        self.tabs = QTabWidget()
        self.tabs.setDocumentMode(True)
        layout.addWidget(self.tabs)
        
        # Create Market View tab
        self.market_widget = MarketWidget(
            settings_service=self.settings_service,
            order_service=self.order_service,
            price_service=self.price_service
        )
        self.tabs.addTab(self.market_widget, "Market View")
        
        # Create Accounts tab
        self.accounts_widget = AccountsWidget(self)
        self.tabs.addTab(self.accounts_widget, "Accounts")
        
        # Set default tab
        self.tabs.setCurrentIndex(0)
        
        # Connect tab change signal
        self.tabs.currentChanged.connect(self.on_tab_changed)
    
    def show_login(self):
        """Show the login dialog on startup"""
        account_id = self.accounts_widget.show_login_dialog()
        # Try to set active account from either the returned id or the store's
        # current_account (some flows set current_account during login).
        from accounts.store import AppStore as _AppStore
        store = _AppStore.instance()

        # Prefer the explicit account_id returned from the dialog
        final_account = account_id

        # Fallback to store.current_account if needed
        if not final_account:
            try:
                cur = store.get_current_account()
                if cur:
                    final_account = cur.get("account_id") or cur.get("account_number")
            except Exception:
                final_account = None

        if not final_account:
            print("No account selected or login cancelled — starting without active account.")
            return

        # Pass the selected account id to MarketWidget so it can start live updates
        try:
            self.market_widget.set_account_id(final_account)
        except Exception:
            pass
    
    def on_tab_changed(self, index):
        """Handle tab change events"""
        if index == 0:
            print("Switched to Market View")
        elif index == 1:
            print("Switched to Accounts")
    
    def closeEvent(self, event):
        """Handle window close event"""
        # Save window settings
        self.settings_service.set('window_width', self.width())
        self.settings_service.set('window_height', self.height())
        
        event.accept()


def main():
    """Main application entry point"""
    app = QApplication(sys.argv)
    
    # Set application properties
    app.setApplicationName("Trade Platform")
    app.setOrganizationName("TradePro")
    
    # Create and show main window
    window = LeftPanelApp()
    window.show()
    
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
