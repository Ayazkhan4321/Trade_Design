"""
Core package - Business logic and data management
"""
from .symbol_manager import SymbolManager

__all__ = ['SymbolManager']
