"""Configuration package"""
from .ui_config import COLORS, SIZES, FONTS, BUTTON_STYLES, INPUT_STYLE
from .app_config import AppConfig

__all__ = ['COLORS', 'SIZES', 'FONTS', 'BUTTON_STYLES', 'INPUT_STYLE', 'AppConfig']
