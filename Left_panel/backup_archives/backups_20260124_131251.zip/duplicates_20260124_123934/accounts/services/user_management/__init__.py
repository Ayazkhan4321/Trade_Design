# User Management Microservice
from .service import UserManagementService

__all__ = ['UserManagementService']
