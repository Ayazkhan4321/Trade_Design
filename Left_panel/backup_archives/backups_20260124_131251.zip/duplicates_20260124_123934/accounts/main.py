import sys
from PySide6.QtWidgets import QApplication, QMainWindow, QTreeWidget, QVBoxLayout, QWidget, QTabWidget, QMessageBox, QTreeWidgetItemIterator
from PySide6.QtCore import Qt, QEvent, QThread
from accounts.login_page import LoginPage
from accounts.store import AppStore
from accounts.accounts_tree import build_accounts_tree
from accounts.add_user_dialog import AddUserDialog
from accounts.remove_user_dialog import RemoveUserDialog
from accounts.switch_account_dialog import SwitchAccountDialog
from accounts.login_worker import LoginWorker
from accounts.account_mapper import map_login_response


class MainWindow(QMainWindow):
    def __init__(self, auto_login=True):
        super().__init__()
        self.setWindowTitle("Accounts Manager")
        self.setGeometry(100, 100, 800, 600)
        
        # Store the API response
        self.api_response = None
        
        # Setup UI
        self.setup_ui()
        
        # Show login page on startup only if auto_login is True
        if auto_login:
            self.show_login()
    
    def setup_ui(self):
        """Setup the main window UI with tabs."""
        # Apply light theme stylesheet
        self.setStyleSheet("""
            QMainWindow {
                background-color: #ffffff;
            }
            QTabWidget::pane {
                border: none;
                background-color: #ffffff;
            }
            QTabBar::tab {
                background-color: #f1f5f9;
                color: #475569;
                padding: 10px 20px;
                border: none;
                border-bottom: 2px solid transparent;
            }
            QTabBar::tab:selected {
                color: #2563eb;
                border-bottom: 2px solid #2563eb;
                background-color: #ffffff;
            }
            QTabBar::tab:hover {
                color: #1e293b;
            }
        """)
        
        # Create central widget with tabs
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        layout = QVBoxLayout(central_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Create tab widget
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs)
        
        # Market View tab (placeholder)
        market_widget = QWidget()
        market_widget.setStyleSheet("background-color: #ffffff;")
        self.tabs.addTab(market_widget, "Market View")
        
        # Accounts tab with tree
        accounts_widget = QWidget()
        accounts_widget.setStyleSheet("background-color: #ffffff;")
        accounts_layout = QVBoxLayout(accounts_widget)
        accounts_layout.setContentsMargins(0, 0, 0, 0)
        
        # Create tree widget for accounts
        self.accounts_tree = QTreeWidget()
        self.accounts_tree.setHeaderHidden(True)
        self.accounts_tree.setStyleSheet("""
            QTreeWidget {
                background-color: #ffffff;
                color: #1e293b;
                font-size: 14px;
                border: none;
                outline: none;
            }
            QTreeWidget::item {
                padding: 8px;
                border: none;
            }
            QTreeWidget::item:hover {
                background-color: #f1f5f9;
            }
            QTreeWidget::item:selected {
                background-color: #e0e7ff;
                color: #1e293b;
            }
            QTreeWidget::branch {
                background-color: #ffffff;
            }
            QTreeWidget::branch:has-children:!has-siblings:closed,
            QTreeWidget::branch:closed:has-children:has-siblings {
                border-image: none;
                image: url(none);
            }
            QTreeWidget::branch:open:has-children:!has-siblings,
            QTreeWidget::branch:open:has-children:has-siblings  {
                border-image: none;
                image: url(none);
            }
        """)
        accounts_layout.addWidget(self.accounts_tree)
        
        # Connect mouse move event for hover handling
        self.accounts_tree.setMouseTracking(True)
        self.accounts_tree.viewport().installEventFilter(self)
        
        # Connect item clicked event for account switching
        self.accounts_tree.itemClicked.connect(self.on_account_clicked)
        
        self.tabs.addTab(accounts_widget, "Accounts")
        
        # Switch to Accounts tab by default
        self.tabs.setCurrentIndex(1)
    
    def show_login(self):
        """Show the login dialog."""
        login_dialog = LoginPage(self)
        login_dialog.login_success.connect(self.on_login_success)
        
        if login_dialog.exec():
            # Login was successful
            pass
        else:
            # Login was cancelled or failed
            sys.exit(0)
    
    def on_login_success(self, login_response):
        """Handle successful login. Accepts full login response object."""
        # login_response is the full response payload emitted by `LoginPage`
        data = login_response.get("data", login_response) if isinstance(login_response, dict) else None
        email = None
        if data:
            email = data.get("email")
        print(f"Login successful for: {email or 'unknown'}")
        
        # Access the store to verify data was saved
        store = AppStore.instance()
        
        # Store the API response data
        self.api_response = {
            "user": store.state["user"],
            "accounts": store.state["accounts"]
        }
        
        print("\n" + "="*60)
        print("STORE DATA:")
        print("="*60)
        print("User Data:", store.state["user"])
        print("\nAccounts - Live Own:", len(store.state["accounts"]["live"]["own"]), "accounts")
        print("Accounts - Demo Own:", len(store.state["accounts"]["demo"]["own"]), "accounts")
        print("Accounts - Live Shared:", len(store.state["accounts"]["live"]["shared"]), "shared groups")
        print("Accounts - Demo Shared:", len(store.state["accounts"]["demo"]["shared"]), "shared groups")
        print("="*60 + "\n")
        
        # Set the first account as the current active account (if available)
        try:
            if store.state["accounts"]["live"]["own"]:
                first_account = store.state["accounts"]["live"]["own"][0]
                # prefer 'number' or 'accountNumber' or 'id'
                acct_number = first_account.get("number") or first_account.get("accountNumber") or str(first_account.get("id") or "")
                store.set_current_account(
                    str(acct_number),
                    email or store.state.get("user", {}).get("email", ""),
                    is_own=True
                )
        except Exception:
            pass
        
        # Build and display the accounts tree
        build_accounts_tree(self.accounts_tree, self.on_add_user_clicked, self.on_remove_user_clicked)
        
        # Update status bar
        self.statusBar().showMessage(f"Logged in as: {email}")
    
    def eventFilter(self, obj, event):
        """Handle hover events for tree items"""
        if obj == self.accounts_tree.viewport():
            if event.type() == QEvent.MouseMove:
                # Use position().toPoint() instead of deprecated pos()
                item = self.accounts_tree.itemAt(event.position().toPoint())
                self._update_delete_button_visibility(item)
            elif event.type() == QEvent.Leave:
                self._update_delete_button_visibility(None)
        return super().eventFilter(obj, event)
    
    def _update_delete_button_visibility(self, hovered_item):
        """Show delete button only for hovered shared user items"""
        iterator = QTreeWidgetItemIterator(self.accounts_tree)
        while iterator.value():
            item = iterator.value()
            delete_button = item.data(0, Qt.UserRole)
            if delete_button:
                # Show button only if this is the hovered item
                delete_button.setVisible(item == hovered_item)
            iterator += 1
    
    def on_add_user_clicked(self):
        """Handle the add user button click"""
        dialog = AddUserDialog(self)
        dialog.user_added.connect(self.on_user_added)
        dialog.exec()
    
    def on_remove_user_clicked(self, user_email, username, accounts):
        """Handle the remove user button click"""
        dialog = RemoveUserDialog(user_email, username, accounts, self)
        dialog.user_removed.connect(self.on_user_removed)
        dialog.exec()
    
    def on_user_added(self, response_data, api_message):
        """Handle successful user addition"""
        print(f"User added successfully: {response_data}")
        
        # Update the store with the newly shared accounts
        store = AppStore.instance()
        shared_accounts = response_data.get('sharedAccounts', [])
        
        if shared_accounts:
            store.add_shared_accounts(shared_accounts)
            
            # Rebuild the tree to show the new shared accounts
            build_accounts_tree(self.accounts_tree, self.on_add_user_clicked, self.on_remove_user_clicked)
        
        # Show the API message
        QMessageBox.information(self, "Success", api_message)
    
    def on_user_removed(self, user_email):
        """Handle successful user removal"""
        print(f"User removed successfully: {user_email}")
        
        # Remove the user from the store
        store = AppStore.instance()
        store.remove_shared_accounts_by_email(user_email)
        
        # Rebuild the tree to reflect the removal
        build_accounts_tree(self.accounts_tree, self.on_add_user_clicked, self.on_remove_user_clicked)
    
    def on_account_clicked(self, item, column):
        """Handle account item click for switching accounts."""
        # Get the text of the clicked item
        account_text = item.text(column)
        
        # Check if it's an account number (numeric string or starts with D for demo)
        if not (account_text.isdigit() or account_text.startswith('D')):
            return  # Not an account, ignore
        
        account_number = account_text
        
        # Find the owner of this account
        store = AppStore.instance()
        accounts = store.get_accounts()
        user_data = store.state.get("user", {})
        current_user_email = user_data.get("email", "").lower()  # Normalize to lowercase
        
        print(f"\n=== Account Click Debug ===")
        print(f"Clicked account: {account_number}")
        print(f"Current logged-in user: {current_user_email}")
        print(f"Live own accounts: {len(accounts['live']['own'])}")
        print(f"Demo own accounts: {len(accounts['demo']['own'])}")
        print(f"Live shared groups: {len(accounts['live']['shared'])}")
        print(f"Demo shared groups: {len(accounts['demo']['shared'])}")
        
        # Check if it's the user's own account
        owner_email = None
        owner_username = None
        is_own = False
        
        # Check in live own accounts
        for acc in accounts["live"]["own"]:
            if str(acc["number"]) == account_number:
                owner_email = current_user_email
                owner_username = user_data.get("fullName") or user_data.get("email", "User")
                is_own = True
                print(f"✓ Found in LIVE OWN accounts")
                break
        
        # Check in demo own accounts
        if not owner_email:
            for acc in accounts["demo"]["own"]:
                if str(acc["number"]) == account_number:
                    owner_email = current_user_email
                    owner_username = user_data.get("fullName") or user_data.get("email", "User")
                    is_own = True
                    print(f"✓ Found in DEMO OWN accounts")
                    break
        
        # Check in live shared accounts
        if not owner_email:
            for shared_group in accounts["live"]["shared"]:
                for acc in shared_group.get("accounts", []):
                    if str(acc["number"]) == account_number:
                        owner_email = shared_group.get("email", "").lower()  # Normalize to lowercase
                        owner_username = shared_group.get("username", "Shared User")
                        is_own = False
                        print(f"✓ Found in LIVE SHARED accounts (owner: {owner_email})")
                        break
                if owner_email:
                    break
        
        # Check in demo shared accounts
        if not owner_email:
            for shared_group in accounts["demo"]["shared"]:
                for acc in shared_group.get("accounts", []):
                    if str(acc["number"]) == account_number:
                        owner_email = shared_group.get("email", "").lower()  # Normalize to lowercase
                        owner_username = shared_group.get("username", "Shared User")
                        is_own = False
                        print(f"✓ Found in DEMO SHARED accounts (owner: {owner_email})")
                        break
                if owner_email:
                    break
        
        if not owner_email:
            print(f"✗ Could not find owner for account {account_number}")
            return
        
        # Check if this is already the active account
        current_account = store.get_current_account()
        if (current_account.get("account_number") == account_number and 
            current_account.get("owner_email", "").lower() == owner_email):
            print(f"⊙ Account {account_number} is already active")
            return
        
        # Determine if we need to verify credentials
        print(f"Comparing: owner_email='{owner_email}' vs current_user_email='{current_user_email}'")
        
        # Get the currently active account's owner
        current_active_account = store.get_current_account()
        current_active_owner = current_active_account.get("owner_email", "").lower()
        
        print(f"Current active account owner: '{current_active_owner}'")
        
        # If the clicked account belongs to the currently logged-in user, allow switching
        # without re-entering credentials (they're already authenticated).
        if owner_email == current_user_email:
            print(f"→ Owner is the logged-in user - switching to account {account_number} without credentials")
            self.switch_account(account_number, owner_email, is_own)
            return

        if owner_email == current_active_owner:
            # Same owner as currently active account - simple switch without credentials
            print(f"→ Same owner as current active account - switching to account {account_number} without credentials")
            self.switch_account(account_number, owner_email, is_own)
        else:
            # Different owner - need verification
            print(f"→ Different owner - requesting credentials for {owner_username}'s account {account_number}")
            self.show_verify_credentials_dialog(account_number, owner_email, owner_username)
    
    def show_verify_credentials_dialog(self, account_number, owner_email, owner_username):
        """Show the verify credentials dialog for switching to a different profile."""
        dialog = SwitchAccountDialog(owner_username, account_number, owner_email, self)
        # account_verified now emits (email, password, is_trade)
        dialog.account_verified.connect(
            lambda email, password, is_trade: self.verify_and_switch_account(account_number, email, password, owner_email, is_trade)
        )
        dialog.exec()
    
    def verify_and_switch_account(self, account_number, email, password, expected_owner_email, is_trade_password=False):
        """Verify credentials and switch account if successful."""
        # Disable the dialog and show loading state
        print(f"Verifying credentials for {email}...")
        print(f"  Account to switch to: {account_number}")
        print(f"  Expected owner: {expected_owner_email}")
        
        # Setup worker thread for authentication
        self.switch_thread = QThread(self)
        self.switch_worker = LoginWorker()
        self.switch_worker.moveToThread(self.switch_thread)
        
        # Store parameters for later use
        self._pending_switch_account = account_number
        self._pending_switch_email = email
        self._pending_switch_expected_email = expected_owner_email
        self._pending_switch_is_trade = is_trade_password
        
        self.switch_thread.started.connect(lambda: self.switch_worker.run("live", email, password))
        
        # Use a proper slot connection instead of lambda to ensure it's called
        self.switch_worker.finished.connect(self._on_switch_worker_finished)
        self.switch_worker.finished.connect(self.switch_thread.quit)
        self.switch_worker.finished.connect(self.switch_worker.deleteLater)
        self.switch_thread.finished.connect(self.switch_thread.deleteLater)
        
        print("Starting authentication thread...")
        self.switch_thread.start()
    
    def _on_switch_worker_finished(self, success, message, response_data):
        """Handle the worker finished signal and call on_verify_complete."""
        print(f"\n=== Worker finished signal received ===")
        print(f"Success: {success}")
        print(f"Message: {message}")
        print(f"Has response data: {response_data is not None}")
        
        # Call the actual verification handler with stored parameters
        self.on_verify_complete(
            success, 
            message, 
            response_data, 
            self._pending_switch_account,
            self._pending_switch_email,
            self._pending_switch_expected_email,
            getattr(self, '_pending_switch_is_trade', False)
        )
    
    def on_verify_complete(self, success, message, response_data, account_number, email, expected_owner_email, is_trade_password=False):
        """Handle verification result - just switch the active account, don't change the tree."""
        print(f"\n=== on_verify_complete called ===")
        print(f"Success: {success}")
        print(f"Email: {email}")
        print(f"Expected owner: {expected_owner_email}")
        print(f"Account number: {account_number}")
        
        if not success:
            print(f"✗ Verification failed: {message}")
            QMessageBox.warning(self, "Verification Failed", 
                              f"Could not verify credentials: {message}")
            return
        
        # Verify that the email matches the expected owner (case-insensitive)
        if email.lower() != expected_owner_email.lower():
            print(f"✗ Email mismatch: {email.lower()} != {expected_owner_email.lower()}")
            QMessageBox.warning(self, "Verification Failed", 
                              "The provided credentials do not match the account owner.")
            return
        
        # Credentials verified - just switch to the account without changing the tree structure
        print(f"\n=== Account Switch (Verified) ===")
        print(f"✓ Credentials verified for {email}")
        print(f"→ Switching to account {account_number}")
        print(f"→ Keeping the same tree structure (not reloading profile)")
        
        store = AppStore.instance()

        # Just update the current active account - DON'T change user data or tree structure
        # The account belongs to a different user (shared account), so is_own=False
        # Store whether the credentials provided were trade-level (can_trade)
        store.set_current_account(account_number, email.lower(), is_own=False, account_id=None, is_demo=False)
        # attach trade permission flag
        store.state['current_account']['can_trade'] = bool(is_trade_password)
        
        print(f"✓ Set active account: {account_number} (owner: {email})")
        
        # Rebuild the tree with the SAME data, just different highlighting
        build_accounts_tree(self.accounts_tree, self.on_add_user_clicked, self.on_remove_user_clicked)
        
        print(f"✓ Tree rebuilt with same structure, account {account_number} highlighted")
        
        # Get the original logged-in user
        original_user = store.state.get("user", {})
        original_email = original_user.get("email", "")
        
        # Update status bar to show both the logged-in user and active account
        self.statusBar().showMessage(f"Logged in as: {original_email} | Active account: {account_number} ({email})")
        
        print(f"✓ Successfully switched to account {account_number}\n")
    
    def switch_account(self, account_number, owner_email, is_own):
        """Switch to the specified account within the same profile and update the UI."""
        store = AppStore.instance()
        
        # Update the current account in store (normalize email to lowercase)
        store.set_current_account(account_number, owner_email.lower(), is_own)
        
        # Rebuild the tree to update highlighting
        build_accounts_tree(self.accounts_tree, self.on_add_user_clicked, self.on_remove_user_clicked)
        
        # Show success message
        current_user = store.state.get("user", {})
        current_email = current_user.get("email", "")
        print(f"✓ Switched to account {account_number}")
        self.statusBar().showMessage(f"Logged in as: {current_email} | Active account: {account_number}", 5000)


def main():
    """Main entry point for the application."""
    app = QApplication(sys.argv)
    
    # Set application metadata
    app.setApplicationName("Accounts Manager")
    app.setOrganizationName("YourOrganization")
    
    # Create and show main window
    window = MainWindow()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
