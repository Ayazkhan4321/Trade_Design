from PySide6.QtCore import QObject, Signal
from accounts.auth_service import authenticate


class LoginWorker(QObject):
    finished = Signal(bool, str, object)  # success, message, response_data

    def run(self, account_type, email, password):
        success, message, response_data = authenticate(account_type, email, password)
        self.finished.emit(success, message, response_data)
