"""Compatibility wrapper for AppStore provided by `accounts.store`.

Keep this lightweight wrapper so MarketWatch imports remain unchanged while
the authoritative store implementation lives in `accounts.store`.
"""
from accounts.store import *
