from PySide6.QtWidgets import QDialog, QButtonGroup, QMessageBox
from PySide6.QtCore import Signal, QThread
"""Compatibility wrapper: reuse the centralized login dialog from `accounts`.

MarketWatch previously contained a copy of the login dialog. To avoid
duplication we import and re-export the `LoginPage` from `accounts`.
"""
from accounts.login_page import LoginPage



    # ---------------- SETUP ----------------

    def _setup_defaults(self):
        self.ui.btn_live.setChecked(True)
        self.ui.input_password.setEchoMode(self.ui.input_password.EchoMode.Password)

    def _setup_toggle_buttons(self):
        self.account_group = QButtonGroup(self)
        self.account_group.setExclusive(True)
        self.account_group.addButton(self.ui.btn_live)
        self.account_group.addButton(self.ui.btn_demo)

    def _connect_signals(self):
        self.ui.btn_signin.clicked.connect(self._handle_login)
        self.ui.lbl_create_account.mousePressEvent = self._create_account_clicked
        self.ui.lbl_forgot_password.mousePressEvent = self._forgot_password_clicked

    # ---------------- LOGIN ----------------

    def _handle_login(self):
        email = self.ui.input_email.text().strip()
        password = self.ui.input_password.text()
        account_type = "live" if self.ui.btn_live.isChecked() else "demo"

        if not email or not password:
            self._show_error("Missing Information", "Email and password are required.")
            return

        # Remember email so we can emit it on success
        self._last_email = email

        self.ui.btn_signin.setEnabled(False)

        # Setup worker thread
        self.thread = QThread(self)
        self.worker = LoginWorker()
        self.worker.moveToThread(self.thread)

        self.thread.started.connect(lambda: self.worker.run(account_type, email, password))

        self.worker.finished.connect(self._on_login_result)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)

        self.thread.start()

    def _on_login_result(self, success, message, response_data):
        self.ui.btn_signin.setEnabled(True)

        if not success:
            # Show error only if login fails
            self._show_error("Login Failed", message)
            return

        # ✅ Login successful: process response and populate store
        if response_data:
            store = AppStore.instance()
            
            # Extract data from nested structure
            data = response_data.get("data", response_data)
            
            # Store the full API response
            store.set_api_response(data)
            
            # Set user data
            store.set_user({
                "userId": data.get("userId"),
                "role": data.get("role"),
                "roleId": data.get("roleId"),
                "fullName": data.get("fullName"),
                "email": data.get("email"),
                "accessToken": data.get("accessToken"),
                "token": data.get("token")
            })
            
            # Parse accounts from response data
            live_own = []
            demo_own = []
            live_shared = []
            demo_shared = []
            accounts = data.get('accounts', [])
            for acc in accounts:
                if acc.get('isDemo', False):
                    demo_own.append(acc)
                else:
                    live_own.append(acc)
            # Parse shared accounts
            shared_accounts = data.get('sharedAccounts', [])
            for shared_group in shared_accounts:
                owner = shared_group.get('accountOwner', {})
                accounts = shared_group.get('accounts', [])
                live_shared_group = [acc for acc in accounts if not acc.get('isDemo', False)]
                demo_shared_group = [acc for acc in accounts if acc.get('isDemo', False)]
                if live_shared_group:
                    live_shared.append({'owner': owner, 'accounts': live_shared_group})
                if demo_shared_group:
                    demo_shared.append({'owner': owner, 'accounts': demo_shared_group})
            store.set_accounts(
                live_own=live_own,
                demo_own=demo_own,
                live_shared=live_shared,
                demo_shared=demo_shared
            )
        
        # Emit signal (with email) and close dialog
        # Emit the full login response for downstream use
        self.login_success.emit(response_data)
        self.accept()  # Closes the dialog

    # ---------------- LABEL ACTIONS ----------------

    def _create_account_clicked(self, event):
        self.create_account_requested.emit()

    def _forgot_password_clicked(self, event):
        self.forgot_password_requested.emit()

    # ---------------- HELPERS ----------------

# keep module compatible with `from login_page import LoginPage`
__all__ = ["LoginPage"]

