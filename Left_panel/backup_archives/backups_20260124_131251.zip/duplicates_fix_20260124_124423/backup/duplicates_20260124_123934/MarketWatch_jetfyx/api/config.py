"""Compatibility wrapper: re-export API config from `accounts.api.config`.

The authoritative API configuration lives under `accounts/api/config.py`.
Keeping this thin wrapper ensures existing `MarketWatch_jetfyx` imports
(`from api.config import ...`) continue to work.
"""
from accounts.api.config import *



