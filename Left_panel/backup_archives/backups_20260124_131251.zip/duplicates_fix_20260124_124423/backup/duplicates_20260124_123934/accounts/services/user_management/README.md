# User Management Microservice

This microservice handles user-related operations in a decoupled, maintainable manner.

## Structure

```
services/
└── user_management/
    ├── __init__.py          # Package initialization
    ├── models.py            # Pydantic data models
    └── service.py           # Core service logic
```

## Features

### Add User to Profile

Allows a primary user to add a secondary user to their profile.

**Endpoint**: `/Auth/add-user-to-profile`

**Request Model**:
```python
{
    "primaryUserId": int,
    "secondaryUserEmail": str,
    "secondaryUserPassword": str
}
```

**Response Model**:
```python
{
    "data": dict | None,
    "message": str | None,
    "statusCode": int | None
}
```

## Usage

```python
from services.user_management import UserManagementService
from api.config import API_BASE_URL

# Initialize the service
service = UserManagementService(API_BASE_URL, access_token="your_token")

# Add a user to profile
success, message, data = service.add_user_to_profile(
    primary_user_id=123,
    secondary_email="user@example.com",
    secondary_password="password123"
)

if success:
    print(f"Success: {message}")
else:
    print(f"Error: {message}")
```

## Design Principles

1. **Separation of Concerns**: Service logic is separated from UI code
2. **Type Safety**: Pydantic models ensure data validation
3. **Error Handling**: Comprehensive error handling with clear messages
4. **Logging**: Detailed logging for debugging
5. **Retry Logic**: Automatic retry for transient network errors
6. **Testability**: Easy to mock and test independently

## Authentication

The service supports Bearer token authentication. Pass the access token when initializing:

```python
service = UserManagementService(API_BASE_URL, access_token=token)
```

## Error Handling

The service returns a tuple of `(success, message, data)`:
- **success** (bool): Whether the operation succeeded
- **message** (str): Human-readable message
- **data** (dict | None): Response data if available

## Future Enhancements

- Add more user management operations
- Implement caching for frequently accessed data
- Add rate limiting
- Support batch operations
